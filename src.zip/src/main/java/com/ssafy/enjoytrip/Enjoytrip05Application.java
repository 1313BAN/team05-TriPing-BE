package com.ssafy.enjoytrip;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;


@SpringBootApplication
public class Enjoytrip05Application {
	public static void main(String[] args) {
		SpringApplication.run(Enjoytrip05Application.class, args);
	}
}
