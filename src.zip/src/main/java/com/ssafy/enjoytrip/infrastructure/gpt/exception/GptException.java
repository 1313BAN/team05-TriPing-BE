package com.ssafy.enjoytrip.infrastructure.gpt.exception;

public class GptException {
}
