package com.ssafy.enjoytrip.config;
import org.springframework.ai.chat.client.ChatClient;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

@Configuration
public class AIConfig {

    @Bean
    ChatClient simpleChatClient(ChatClient.Builder builder) {
        // TODO: 02. ChatClient 타입의 빈을 생성해보자.
        return builder.defaultSystem("ddd").build();

        //END
    }

}
